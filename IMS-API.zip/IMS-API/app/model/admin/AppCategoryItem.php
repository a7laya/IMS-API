<?php

namespace app\model\admin;

use think\Model;
use app\model\common\BaseModel;
/**
 * @mixin think\Model
 */
class AppCategoryItem extends BaseModel
{
    //
}
