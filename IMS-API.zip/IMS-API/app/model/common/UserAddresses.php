<?php

namespace app\model\common;

/**
 * @mixin think\Model
 */
class UserAddresses extends BaseModel
{
    
}
